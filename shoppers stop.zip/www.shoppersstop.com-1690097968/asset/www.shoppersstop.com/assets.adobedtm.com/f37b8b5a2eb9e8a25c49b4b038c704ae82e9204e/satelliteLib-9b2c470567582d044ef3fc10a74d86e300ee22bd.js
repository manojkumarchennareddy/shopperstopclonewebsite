<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Page Not Found</title>

<link rel="stylesheet" type="text/css" media="all"
	href="/_ui/responsive/common/assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" media="all"
	href="/_ui/responsive/common/assets/css/common.css">
<link rel="stylesheet" type="text/css" media="all"
	href="/_ui/responsive/common/assets/css/font-awesome.min.css">
<!-- for static pages static.css -->
<link rel="stylesheet" type="text/css" media="all"
	href="/_ui/responsive/common/assets/css/tinyscrollbar.css">

</head>
<body class="serverError">
	<section class="error_body-sec">		
		<div class="empty-container height-adj">   													
			<div class="empty-cont" >
				<div class="error-images">
					<a href="/"><img
						src="/_ui/updated_path/images/Somthing-Went-Wrong.png"
						alt="Somthing-Went-Wrong-Error-Image" />
					</a>
				</div>
				<h2> Oops! </h2>
				<div class="content-area">                  
					Something went wrong? <strong> Reload </strong> the screen 
				</div>
				<a href="#" class="refresh-link" id="Pagerefresh"> Refresh </a>
				</div>
		</div>
	</section>

</body>

<script>
	$(document).on('click', '#Pagerefresh',function(){ 
		location.reload(true);
	});
</script>
</html>


